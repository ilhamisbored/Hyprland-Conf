# tailscale

This plugin provides completion for [tailscale](https://tailscale.com/) (Easy software-defined networks using an implementation of wireguard).

To use it, add `tailscale` to the plugins array in your zshrc file.

```
plugins=(... tailscale)
```

**Author:** [@lukeab](https://github.com/lukeab)
